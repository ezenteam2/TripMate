# TripMate

웹사이트 주소 : https://ezenteam2.github.io/TripMate/.

main화면
main.html에서 main2.hmtl으로 변경~